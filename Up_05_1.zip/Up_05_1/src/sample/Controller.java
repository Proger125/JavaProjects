package sample;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

import java.net.URL;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Controller implements Initializable{
    private Model model;
    public TextField field;
    public ComboBox comboBox;
    public Circle circle;
    public Controller(){
        model = new Model();
        model.addElement("Натуральное число", "^(\\+?[1-9][0-9]*)$");
        model.addElement("Целое число", "^(0|[-\\+]?[1-9][0-9]*)$");
        model.addElement("Дробное число", "^[-\\+]?[0-9]*[.,]?[0-9]+(?:[eE][-\\+]?[0-9]+)?$");
        model.addElement("Дата", "^(?:(?:31(\\/|-|\\.)(?:0?[13578]|1[02]))\\1|(?:(?:29|30)(\\/|-|\\.)(?:0?[1,3-9]|1[0-2])\\2))(?:(?:1[6-9]|[2-9]\\d)?\\d{2})$|^(?:29(\\/|-|\\.)0?2\\3(?:(?:(?:1[6-9]|[2-9]\\d)?(?:0[48]|[2468][048]|[13579][26])|(?:(?:16|[2468][048]|[3579][26])00))))$|^(?:0?[1-9]|1\\d|2[0-8])(\\/|-|\\.)(?:(?:0?[1-9])|(?:1[0-2]))\\4(?:(?:1[6-9]|[2-9]\\d)?\\d{2})$");
        model.addElement("Email", "^((([0-9A-Za-z]{1}[-0-9A-z\\.]{1,}[0-9A-Za-z]{1})|([0-9А-Яа-я]{1}[-0-9А-я\\.]{1,}[0-9А-Яа-я]{1}))@([-A-Za-z]{1,}\\.){1,2}[-A-Za-z]{2,})$");
        model.addElement("Время", "^(([0,1][0-9])|(2[0-3])):[0-5][0-9]$");
    }
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        comboBox.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue observableValue, Object o, Object t1) {
                String str = (String)t1;
                check(str);
            }
        });
        field.textProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observableValue, String s, String t1) {
                check(t1);
            }
        });
    }
    private void check(String t1){
        Pattern pattern = model.getRegularExpresion((String)comboBox.getValue());
        Matcher matcher = pattern.matcher(t1);
        if (matcher.matches()){
            circle.setFill(Color.GREEN);
        }else{
            circle.setFill(Color.RED);
        }
    }
}
