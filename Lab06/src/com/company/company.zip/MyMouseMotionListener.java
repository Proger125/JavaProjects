package com.company;

import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;

public class MyMouseMotionListener implements MouseMotionListener {
    private StatusBar statusBar;
    public MyMouseMotionListener(StatusBar statusBar){
        this.statusBar = statusBar;
    }
    @Override
    public void mouseDragged(MouseEvent e) {

    }

    @Override
    public void mouseMoved(MouseEvent e) {
        this.statusBar.setMessage(e.getX() + " " + e.getY());
    }
}
