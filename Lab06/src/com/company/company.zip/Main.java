package com.company;

import javax.swing.*;
import java.awt.*;

public class Main {

    public static void main(String[] args) {
        JFrame frame = new JFrame("Lab06");
        frame.setMinimumSize(new Dimension(800, 500));
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel panel = new JPanel(null);
        JButton button = new JButton("Button");
        button.setLocation(50,50);
        button.setSize(100,20);
        panel.add(button);
        StatusBar statusBar = new StatusBar();
        statusBar.setLocation(0, frame.getSize().height - 100);
        MyMouseMotionListener listener = new MyMouseMotionListener(statusBar);
        frame.addMouseMotionListener(listener);
        panel.add(statusBar);
        frame.setContentPane(panel);
        frame.setVisible(true);
    }
}
