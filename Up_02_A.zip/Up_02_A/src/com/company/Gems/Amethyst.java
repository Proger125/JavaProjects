package com.company.Gems;

public class Amethyst extends Gem{
    public Amethyst(double weight, double cost, double transparency) {
        super("Аметист", weight, cost, transparency);
    }
}
