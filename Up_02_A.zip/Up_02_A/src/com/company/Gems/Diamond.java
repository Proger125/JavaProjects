package com.company.Gems;

public class Diamond extends Gem{
    public Diamond(double weight, double cost, double transparency) {
        super("Алмаз", weight, cost, transparency);
    }
}
