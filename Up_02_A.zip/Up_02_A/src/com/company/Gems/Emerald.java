package com.company.Gems;

public class Emerald extends Gem{
    public Emerald(double weight, double cost, double transparency) {
        super("Изумруд", weight, cost, transparency);
    }
}
