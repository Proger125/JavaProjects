package com.company.Gems;

public class Ruby extends Gem{
    public Ruby(double weight, double cost, double transparency) {
        super("Рубин", weight, cost, transparency);
    }
}
