package com.company.SortingStrategy;

import com.company.Gems.Gem;

import java.util.List;

public interface Sorting {
    void sort(List<Gem> list);
}
