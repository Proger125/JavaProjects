package com.company.CalcStrategy;

import com.company.Gems.Gem;

import java.util.List;

public interface Calc {
    double calc(List<Gem> list);
}
